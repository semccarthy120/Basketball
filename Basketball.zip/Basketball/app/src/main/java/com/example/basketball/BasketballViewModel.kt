package com.example.basketball

import androidx.lifecycle.ViewModel

    private const val TAG = "BasketballViewModel"

    class BasketballViewModel : ViewModel() {

        var scoreA = 0
        var scoreB = 0

        val retrieveScoreA: Int
            get() = scoreA

        val retrieveScoreB: Int
            get() = scoreB

        fun threeA() {
            scoreA += 3
        }

        fun threeB() {
            scoreB += 3
        }
        fun twoA() {
            scoreA += 2
        }

        fun twoB() {
            scoreB += 2
        }

        fun freeA() {
            scoreA += 1
        }

        fun freeB() {
            scoreB += 1
        }

        fun resetScore() {
            scoreA = 0
            scoreB = 0
        }



    }
