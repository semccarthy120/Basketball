package com.example.basketball

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProviders

private const val TAG = "MainActivity"
private const val KEY_INDEX = "index"

class MainActivity : AppCompatActivity() {

    private lateinit var threeAButton : Button
    private lateinit var twoAButton : Button
    private lateinit var freeAButton : Button

    private lateinit var threeBButton : Button
    private lateinit var twoBButton : Button
    private lateinit var freeBButton : Button

    private lateinit var resetButton : Button

    private val basketballViewModel: BasketballViewModel by lazy {
        ViewModelProviders.of(this).get(BasketballViewModel::class.java)
    }

        var score = 0

        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate(Bundle?) called")
        setContentView(R.layout.activity_main)

        threeAButton = findViewById(R.id.three_button)
        twoAButton = findViewById(R.id.two_button)
        freeAButton = findViewById(R.id.free_button)

        threeBButton = findViewById(R.id.threeb_button)
        twoBButton = findViewById(R.id.twob_button)
        freeBButton = findViewById(R.id.freeb_button)

        resetButton = findViewById(R.id.reset_button)

        threeAButton.setOnClickListener { view: View ->
            basketballViewModel.threeA()
            val displayA = findViewById<TextView>(R.id.display_scorea)
            score = basketballViewModel.retrieveScoreA
            displayA.text = "$score"
        }
        twoAButton.setOnClickListener { view: View ->
            basketballViewModel.twoA()
            val displayA = findViewById<TextView>(R.id.display_scorea)
            score = basketballViewModel.retrieveScoreA
            displayA.text = "$score"
        }
        freeAButton.setOnClickListener { view: View ->
            basketballViewModel.freeA()
            val displayA = findViewById<TextView>(R.id.display_scorea)
            score = basketballViewModel.retrieveScoreA
            displayA.text = "$score"
        }
        threeBButton.setOnClickListener { view: View ->
            basketballViewModel.threeB()
            val displayB = findViewById<TextView>(R.id.display_scoreb)
            score = basketballViewModel.retrieveScoreB
            displayB.text = "$score"
        }
        twoBButton.setOnClickListener { view: View ->
            basketballViewModel.twoB()
            val displayB = findViewById<TextView>(R.id.display_scoreb)
            score = basketballViewModel.retrieveScoreB
            displayB.text = "$score"
        }
        freeBButton.setOnClickListener { view: View ->
            basketballViewModel
            val displayB = findViewById<TextView>(R.id.display_scoreb)
            score = basketballViewModel.retrieveScoreB
            displayB.text = "$score"
        }
        resetButton.setOnClickListener { view: View ->
            basketballViewModel.resetScore()
            val displayA = findViewById<TextView>(R.id.display_scorea)
            score = basketballViewModel.retrieveScoreA
            displayA.text = "$score"
            val displayB = findViewById<TextView>(R.id.display_scoreb)
            score = basketballViewModel.retrieveScoreB
            displayB.text = "$score"
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart() called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume() called")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause() called")
    }

        override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop() called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy() called")
    }

}

